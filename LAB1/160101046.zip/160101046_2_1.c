#include <stdio.h>
#include <stdlib.h>

typedef struct _node{
	int data;
	struct _node * left;
	struct _node * right;
}node;

node * getnode(){
	node * temp = (node*)malloc(sizeof(node));
	temp->left = NULL;
	temp->right = NULL;
	return temp;
}
//searches q in tree
node * find(node * root, int q){
	 
	if(root==NULL)return NULL;
	if((root->data)==q)return root;
	else{
		node * temp = find(root->left, q);
		if(temp!=NULL)return temp;
		if(temp==NULL){
			temp = find(root->right,q);
			if(temp!=NULL)return temp;
		}
		return temp;
	}
}
//inserts elements in q
node * ins(node * root, int p, char a, int q){
	node * temp = getnode();
	temp->data = p;
	node * temp1;
	if(root==NULL){
		root = temp;
		return root;
	}
	temp1 = find(root, q);
	if(a=='L'){
		if((temp1->left)!=NULL){
			printf("%d is ignored\n", p);
			return root;

		}
		else{
			temp1->left = temp;
			return root;
		} 
	}	
	if(a=='R'){
		if((temp1->right)!=NULL){
			printf("%d is ignored\n", p);
				return root;		
		}
		else {
			temp1->right = temp;
			return root;	
		}
				
	}
	
}

void inorder(node * root){

	
	if((root->left)!=NULL)inorder(root->left);
	printf("%d ", root->data);
	if((root->right)!=NULL)inorder(root->right);
}
	
void postorder(node * root){
	if((root->left)!=NULL)postorder(root->left);
	if((root->right)!=NULL)postorder(root->right);
	printf("%d ", root->data);

}

void preorder(node * root){
	printf("%d ", root->data);
	if((root->left)!=NULL)preorder(root->left);
	if((root->right)!=NULL)preorder(root->right);
	

}

void printleafnode(node * root){

	if(root==NULL)return;
	if(root->left==NULL&&root->right==NULL){printf("%d ", root->data);return;}
	else{
		printleafnode(root->left);
		printleafnode(root->right);
	}
}

int main(){
	int p;
	char a;
	int q;

	node * root = NULL;
	while(1){
		scanf("%d", &p);
		if(p==-1)break;
		scanf(" %c", &a);
		scanf("%d", &q);

		root = ins(root, p, a, q);
	}
	if(root!=NULL){
	printf("Inorder : ");
	inorder(root);
	printf("\n");
	printf("Preorder : ");
	preorder(root);
	printf("\n");
	printf("Postorder : ");
	postorder(root);
	printf("\n");
	printf("Leaf Nodes : ");
	printleafnode(root);
	printf("\n");
	}
	else printf("Tree is empty\n");
	
	return 0;
}